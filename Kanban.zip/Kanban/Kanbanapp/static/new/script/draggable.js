const list_items = document.querySelectorAll('.list-item');
const lists = document.querySelectorAll('.list');
tasks = document.querySelectorAll('.levels');

let draggedItem = null;

for (let i = 0; i < list_items.length; i++) {
    const item = list_items[i];

    item.addEventListener('dragstart', function() {
        draggedItem = item;
        console.log("inside dragstart");
        setTimeout(function() {
            item.style.display = 'none';
        }, 0)
    });

    item.addEventListener('dragend', function() {
        console.log("inside dragged");
        setTimeout(function() {
            draggedItem.style.display = 'block';
            draggedItem = null;
        }, 0);

        // getting the count of tasks on diff sets
        var tasksCount = [];
        for (let i = 0; i < tasks.length; i++) {
            console.log(tasks[i].childElementCount - 2);
            tasksCount.push(tasks[i].childElementCount - 2);
        }

        document.getElementById("todo-count").textContent = tasksCount[0];
        document.getElementById("inprogress-count").textContent = tasksCount[1];
        document.getElementById("codereview-count").textContent = tasksCount[2];
        document.getElementById("intesting-count").textContent = tasksCount[3];
        document.getElementById("done-count").textContent = tasksCount[4];
    })

    for (let j = 0; j < lists.length; j++) {
        const list = lists[j];

        list.addEventListener('dragover', function(e) {
            console.log("inside dragover");
            e.preventDefault();
        });

        list.addEventListener('dragenter', function(e) {
            console.log("inside dragcenter");
            e.preventDefault();
            this.style.backgroundColor = 'rgba(0, 0, 0, 0.2)';
        });

        list.addEventListener('dragleave', function(e) {
            console.log("inside dragleave");
            this.style.backgroundColor = 'rgba(0, 0, 0, 0.1)';
        });

        list.addEventListener('drop', function(e) {
            console.log("inside drop");
            this.append(draggedItem);
            this.style.backgroundColor = 'rgba(0, 0, 0, 0.0)';
        });
    }
}



const projects = [
    {
      id: 1,
      name: "Project 1",
      description: "Description of Project 1",
      startDate: "2023-05-16",
      endDate: "2023-05-20"
    },
    {
      id: 2,
      name: "Project 2",
      description: "Description of Project 2",
      startDate: "2023-05-21",
      endDate: "2023-05-25"
    }
  ];
  
  // Function to dynamically create project rows in the table
  function createProjectRow(project) {
    const row = document.createElement("tr");
  
    row.innerHTML = `
      <td>${project.id}</td>
      <td>${project.name}</td>
      <td>${project.description}</td>
      <td>${project.startDate}</td>
      <td>${project.endDate}</td>
      <td><button class="deleteBtn">Delete</button></td>
      <td><button class="taskBtn">Task</button></td>
    `;
  
    return row;
  }
  
  // Function to populate the project table with sample data
  function populateProjectTable() {
    const projectTable = document.getElementById("projectTable");
  
    projects.forEach((project) => {
      const row = createProjectRow(project);
      projectTable.appendChild(row);
    });
  }
  
  // Function to handle delete button clicks (event delegation)
  document.addEventListener("click", (e) => {
    if (e.target.classList.contains("deleteBtn")) {
      const row = e.target.parentElement.parentElement;
      row.remove();
      // Additional logic to handle deletion from the projects array if necessary
    }
  });
  
  // Call the populateProjectTable function to initially populate the table
  populateProjectTable();
  