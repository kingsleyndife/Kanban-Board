// Function to handle form submission
function createTask(event) {
    event.preventDefault();
  
    // Retrieve form values
    const name = document.getElementById("name").value;
    const description = document.getElementById("description").value;
    const assignTo = document.getElementById("assignTo").value;
    const priority = document.getElementById("priority").value;
    const status = document.getElementById("status").value;
    const estimatedHours = document.getElementById("estimatedHours").value;
    const progressHours = document.getElementById("progressHours").value;
    const remainingHours = document.getElementById("remainingHours").value;
  
    // Create a task object
    const task = {
      name: name,
      description: description,
      assignTo: assignTo,
      priority: priority,
      status: status,
      estimatedHours: estimatedHours,
      progressHours: progressHours,
      remainingHours: remainingHours
    };
  
    // Perform further actions with the task object (e.g., save to database, display on a page, etc.)
  
    // Clear the form fields
    document.getElementById("createTaskForm").reset();
  }
  
  // Add event listener to the form
  document.getElementById("createTaskForm").addEventListener("submit", createTask);
  